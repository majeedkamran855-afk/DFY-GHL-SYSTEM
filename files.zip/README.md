# WholesaleOS

Property-first CRM/automation platform architecture for high-volume US real estate
wholesaling operations. This repo currently contains architecture-stage scaffolding:
schema, workflow-engine, and valuation-engine reference code extracted from the
full technical spec.

## Layout

```
.
├── docs/
│   └── architecture.md        # Full technical architecture spec (stack, schema, roadmap)
├── prisma/
│   └── schema.prisma           # Property-first Postgres schema (Prisma syntax)
└── src/
    ├── workflow/
    │   ├── workflow.ts          # Temporal workflow definition (visual automation engine)
    │   └── activities.ts        # Activity stubs invoked by the workflow (wire to services)
    └── valuation/
        └── mao-calculator.ts    # ARV estimation + MAO ("70% rule") calculation
```

## Status

Architecture/scaffolding stage — activities.ts contains stubs (`throw new Error('Not implemented')`)
that need to be wired to the actual Telephony/CRM microservices described in `docs/architecture.md`
before this runs. Not yet a working application.

## Getting this into GitHub

This code was generated in a chat environment without direct GitHub access. To push it:

```bash
# from the folder containing this README
git init
git add .
git commit -m "Initial architecture scaffolding: schema, workflow engine, MAO calculator"
git branch -M main
git remote add origin https://github.com/<your-username>/<your-repo>.git
git push -u origin main
```

If the repo doesn't exist yet, create it first at https://github.com/new (or via
`gh repo create <your-repo> --private --source=. --remote=origin --push` if you have the
GitHub CLI installed, which combines repo creation and the push above into one step).
